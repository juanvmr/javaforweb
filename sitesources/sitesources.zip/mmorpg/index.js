function submit(form){
    
}

var criarButton = document.getElementById("criarButton")
criarButton.addEventListener("click", submit(document.getElementById("mainForm")))